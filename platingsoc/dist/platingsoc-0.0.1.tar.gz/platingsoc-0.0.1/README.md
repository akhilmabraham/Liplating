# platingSoC

[![PyPI - Version](https://img.shields.io/pypi/v/platingsoc.svg)](https://pypi.org/project/platingsoc)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/platingsoc.svg)](https://pypi.org/project/platingsoc)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install platingsoc
```

## License

`platingsoc` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
